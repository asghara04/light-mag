from django.contrib import admin
from .models import Category, SubCat

admin.site.register(Category)
admin.site.register(SubCat)